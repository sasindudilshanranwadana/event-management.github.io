<template>
    <div>
      <h1>Content Page</h1>
      <ul>
        <li v-for="item in items" :key="item.id">{{ item.title }}: {{ item.body }}</li>
      </ul>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        items: []
      };
    },
    methods: {
      fetchData() {
        axios.get('http://localhost/your_php_folder/fetch_content.php')
          .then(response => {
            this.items = response.data;
          })
          .catch(error => {
            console.error('Error fetching data:', error);
          });
      }
    },
    created() {
      this.fetchData();
    }
  };
  </script>
  